Commerce Repeat Order allows end user to repeat there order again and again.

This module allows to repeat customer order just by creating an simple link or
button.

i.e. Link can be created as l('Repeat Order','commerce-repeat-order/%') where 
% is order id which needs to be passed dynamically to repeat that order.

Order of same user will be allowed to repeat. Order of another user will not be
added to cart by different customer.

