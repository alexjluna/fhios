<?php

namespace Drupal\module_name\lib\redsys\Exception;

use Exception;

/**
 * Clase RedSysException.
 *
 * Da nombre a los errores propios de la clase RedSys.
 */
class RedSysException extends Exception {
}
