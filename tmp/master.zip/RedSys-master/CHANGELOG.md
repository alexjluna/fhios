# Histórico de cambios
>Todos los cambios notables de este proyecto se documentarán en este archivo.

## [v0.0.1] - 2020-10-07
> Primera versión.
