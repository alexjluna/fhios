---
name: Nueva funcionalidad
about: Sugerir una idea para este proyecto
title: ''
labels: ''
assignees: ''

---

**¿Su solicitud de función está relacionada con un problema? Por favor descríbalo.**
Una descripción clara y concisa de cuál es el problema.
Ej. Siempre me frustra cuando [...]

**Describa la solución que le gustaría**
Una descripción clara y concisa de lo que quiere que suceda.

**Describe las alternativas que ha considerado**
Una descripción clara y concisa de cualquier solución o característica
alternativa que haya considerado.

**Información adicional**
Agregue cualquier otro contexto o capturas de pantalla sobre la solicitud de
función aquí.
